Website URLs:

https://d1urzkllfgeo81.cloudfront.net/

http://myproject1bucket1234.s3-website-us-east-1.amazonaws.com/

https://myproject1bucket1234.s3.amazonaws.com/index.html